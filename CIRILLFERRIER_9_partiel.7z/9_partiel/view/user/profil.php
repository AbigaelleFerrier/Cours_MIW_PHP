<h1><?php echo $user->name ?></h1>

<a href="<?php echo ROOT?>/user/delete?id=<?php echo $user->id?>">Supprimer le compte</a>