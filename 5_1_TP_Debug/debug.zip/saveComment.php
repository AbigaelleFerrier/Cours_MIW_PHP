<?php
require 'config.php';
$bdd = getDB();

$req = $bdd->prepare('INSERT INTO commentaire (titre, contenu, id_user, id_article, datetime) 
        VALUES (:tittre, :contenu, :id_user,:id_article,NOW())');
$req->bindValues('titre', $_POST['titre']);
$req->bindValues('contenu', $_POST['contenu']);
$req->bindValues('id_user', $_POST['id_user']);
$req->bindValues('id_article', $_POST['id_article']);
$req->execute();

header('Location: article.php?id_article='.(int)$_POST['id_article']);