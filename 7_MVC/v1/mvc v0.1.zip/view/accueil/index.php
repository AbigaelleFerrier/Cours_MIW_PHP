mon fichier index.html

<?php
    var_dump($livres);
    var_dump($test);
    var_dump($test2);
?>