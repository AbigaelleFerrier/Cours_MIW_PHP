<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TP MVC V3</title>
    <style>
        h1 {
            margin-bottom: 1rem;
        }
        a {
            cursor: pointer;
            padding: 0.1em 0.5rem;
            background: #444;
            color: #fff;
            text-align: center;
        }
    
    </style>
</head>
<body>