mon fichier index.html

<?php
    var_dump($livres);
?>