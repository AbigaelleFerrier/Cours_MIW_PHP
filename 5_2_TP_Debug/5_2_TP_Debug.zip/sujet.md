// OK
La création/modification d'un article avec upload d'une image, 
afficher cette image dans article.php (largeur max 1000px) et 
dans les listes d'articles (format 100*100). Redimensionner et
 tailler l'image en conséquence.



// OK
Ajouter un lien sur le nom de l'auteur dans article.php qui pointe 
sur une page auteur.php et qui liste les infos de l'auteur (nom et 
email), tous ses articles et tous ses commentaires


// OK
Créer une page admin.php qui listera tout les utilisateurs avec 
possibilité d'ajouter/modifier/supprimer les utilisateurs.



bonus : possibilité d'ajouter une image de profil aux utilisateurs
 (sans changer la base, utilisez l'id de l'utilisateur pour enregistrer l'image).
