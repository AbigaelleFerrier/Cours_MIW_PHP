<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Cirill Ferrier</title>
        <link rel="stylesheet" href="<?php echo ROOT?>/assets/css/style.css">
    </head>
    <body>
    <a href="<?php echo ROOT ?>">Accueil</a>

    <?php echo $content ?>

    <?php
    
    ?>
    </body>
</html>